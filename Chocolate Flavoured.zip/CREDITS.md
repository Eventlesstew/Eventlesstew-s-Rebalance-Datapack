# Eventlesstew
- Making the Datapack in it's entirety.

# Slimester

## General
- Main Inspiration
- Feedback

- Mob Rebalance System
- Item Rebalance System
- Dynamic Lighting
- Weapon stat rebalances
- Food stat rebalances

## New Content
- Hammers
- Daggers (Was my idea, but he polished it)
- Rose Golden Gear
- Shields
- Totem of Warping
- Magnets

## Textures
- Pressure Plate Textures
- Rose Golden Nuggets (Made specifically for this datapack)
- Creakstep Music Disc

## Recipes
- Slab
- Stairs
- Signs
- Hanging Sign (Modified)

## Item Reworks
- Fences (Modified)
- Copper Compass
- Copper Shears
- Copper Powered Rail (Modified)
- Copper Comparator

## Enchantments
- Acceleration
- Bookworm Bait
- Seine
- Breach (Rework + Texture)
- Buffalo (Function + Texture)
- Bulwark (Function + Texture)
- Combo
- Crackle (Function + Texture)
- Density (Texture Only)
- Echo (Function + Texture)
- Efficiency (Texture Only)
- Eternity
- Feasting
- Feather Falling (Texture Only)
- Focusing
- Fowling
- Galloping (Part of the function)
- Guiding
- Homing
- Impaling (Texture Only)
- Live Catch
- Melting
- Mending (Rework)
- Protection (Texture Only)
- Punch (Rework)
- Rampage (Function + Texture)
- Rebound
- Ricochet
- Valor

## Food
Much of the existing food rebalances or reworks were based on his ideas.

However, he made the textures and initial ideas for these items:
- Cooked Tropical Fish
- Chocolate
- Cheese
- Blue Cheese
- Cupcake
- Apple Pie
- Berry Pie
- Beef Pie (Modified)
- Salad
- Sea Salad

## Biomes
- Biome Overhaul

## Structures
- Axolotls spawning in Ocean Monuments
- Helped with Structure reworks

# Sturbo
- Insightful Feedback

# Mr. Tusky
- Insightful Feedback
- Helped with Structure reworks

# Terrozei
- Insightful Feedback

# AbcCrazy
- Insightful Feedback
- Playtesting
- Potion of Haste
- Biscuits

# Vanilla Tweaks
https://vanillatweaks.net/

Optional Resource Pack Tweaks:
- Flint Tipped Arrows
- Old XP sounds
- Iron Golem Roses
- Consistent Blank Pot Side
- Age 25 Kelp
- Different Melon and Pumpkin Stems
- Indicated Infested and Waxed Blocks
- Bucket Pixel Fix
- Brown Leather
- Sulfur Cube Goo Fix
- Transparent Pumpkin Overlay

Rebalance Resource Pack Tweaks:
- Pixel Consistent Signs, Sonic Boom, Experience Orbs
- Redstone Lever Groove 
- Painting Items

Datapack Tweaks
- Unpackable Packed/Blue Ice

technically i came up with these ideas without finding out they already exist on vanilla tweaks but uhhh just to be safe.
- Wood Stripper
- Ender Chest Always Drops
- Glass Always Drops

# Klei Wright
This guy is the creator of Matcha Flavoured, a datapack that had some influence on key things in this mod.

Inspirations
- Cheaper Campfires
- Smeltable Grass to Dry Grass
- Cheaper Mud Crafting
- Potion Effects from eating food

# Blaze and Cave's Advancements
- On a Rail
- Face Reveal

# Antimo and Welles
https://antimo.bandcamp.com/album/minecraft-story-mode-original-soundtrack

Made the MCSM OST that has been featured in this datapack:
- Ivor Theme (Ivor)
- 103 Credits (Mob Grinder)
- 104 Credits (Far Lands)

# ChasePixel_
https://www.planetminecraft.com/texture-pack/enchanting-table-book-on-enchantment-table-item-model/

- Adding the Enchanting Table's Book in the Inventory Model