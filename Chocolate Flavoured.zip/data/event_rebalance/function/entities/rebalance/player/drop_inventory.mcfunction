execute store result score difficulty temp run difficulty
execute if score difficulty temp <= 0 static run return fail 

function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"hotbar.0"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"hotbar.1"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"hotbar.2"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"hotbar.3"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"hotbar.4"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"hotbar.5"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"hotbar.6"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"hotbar.7"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"hotbar.8"}

function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.0"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.1"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.2"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.3"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.4"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.5"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.6"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.7"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.8"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.9"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.10"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.11"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.12"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.13"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.14"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.15"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.16"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.17"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.18"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.19"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.20"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.21"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.22"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.23"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.24"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.25"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"inventory.26"}

function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"armor.head"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"armor.chest"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"armor.legs"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"armor.feet"}

function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"weapon.offhand"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"player.cursor"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"player.crafting.0"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"player.crafting.1"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"player.crafting.2"}
function event_rebalance:entities/rebalance/player/drop_item {inventory_slot:"player.crafting.3"}