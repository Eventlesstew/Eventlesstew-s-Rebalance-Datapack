#gamerule keep_inventory true

# Add scoreboards if they don't exist
scoreboard objectives add event.player_deaths deathCount
scoreboard objectives add temp dummy
scoreboard objectives add timer dummy
scoreboard objectives add static dummy
scoreboard objectives add event_rebalance.flat_damage_enchantment_cooldown dummy
scoreboard objectives add event_rebalance.acceleration_count dummy
scoreboard objectives add event_rebalance.combo_timer dummy
scoreboard objectives add event_rebalance.castaway_timer dummy
scoreboard objectives add event_rebalance.magnet_pull_strength dummy
scoreboard objectives add event_rebalance.magnet_sound dummy
scoreboard objectives add event_rebalance.magnet_pull_sound dummy
scoreboard objectives add event_rebalance.magnet_pull_time dummy
scoreboard objectives add extra_hearts dummy
scoreboard objectives add on_a_rail.start.x dummy
scoreboard objectives add on_a_rail.start.y dummy
scoreboard objectives add on_a_rail.start.z dummy
scoreboard objectives add on_a_rail.start.dist dummy
scoreboard objectives add event.reset_items trigger
scoreboard objectives add balance.squeeze_active dummy

# Set values
scoreboard players set armor_stand_eye_height static 15415
scoreboard players set -1575 static -1575
scoreboard players set -1125 static -1125
scoreboard players set -675 static -675
scoreboard players set -225 static -225
scoreboard players set 0 static 0
scoreboard players set 1 static 1
scoreboard players set 2 static 2
scoreboard players set 3 static 3
scoreboard players set 4 static 4
scoreboard players set 5 static 5
scoreboard players set 6 static 6
scoreboard players set 7 static 7
scoreboard players set 8 static 8
scoreboard players set 9 static 9
scoreboard players set 10 static 10
scoreboard players set 20 static 20
scoreboard players set 60 static 60
scoreboard players set 64 static 64
scoreboard players set 225 static 225
scoreboard players set 500 static 500
scoreboard players set 675 static 675
scoreboard players set 1000 static 1000
scoreboard players set 1125 static 1125
scoreboard players set 1200 static 1200
scoreboard players set 1575 static 1575
scoreboard players set 6000 static 6000
scoreboard players set max_extra_hearts static 10
scoreboard players set 180_arrow static 1800000

gamerule spawn_phantoms false
gamerule keep_inventory true
gamerule max_minecart_speed 1000
gamerule players_sleeping_percentage 1

function event_rebalance:enchantments/common/restart_all

bossbar add event_rebalance:illusioner {translate:entity.minecraft.illusioner}
bossbar set event_rebalance:illusioner color blue
bossbar add event_rebalance:wildfire {translate:entity.event.wildfire}
bossbar set event_rebalance:wildfire color yellow

function event_rebalance:reset_items